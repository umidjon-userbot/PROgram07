<?php

include '_config.php';
 $msgID = $update['update']['message']['id'];
 $r = $MadelineProto
            ->channels
            ->getMessages(['channel' => $chatID, 'id' => [$mesid]]);
        $id = $r['messages'][0]['from_id'];
/*
QUESTO FILE SERVE PER AVERE SEPARATI I COMANDI DELL'USERBOT
DAI FILE BASE DI FUNZIONAMENTO DELLO STESSO
*/

if (isset($userID) && in_array($userID, $lista_admin)) {
    $isadmin = true;
} else {
    $isadmin = false;
}

if (isset($msg) && isset($chatID)) {
    if ($isadmin) {
        if (stripos($msg, '!say ') === 0) {
           setTyping($chatID);
           deleteMsg($chatID,$msgID);
           sm($chatID, explode(' ', $msg, 2)[1]);
        }

        if ($msg == '!off' and (time() - $started) > 5) {
            sm($chatID, 'offffffffff.');
            exit;
        }

        if (stripos($msg, '!join ') === 0) {
            joinChat(explode(' ', $msg, 2)[1], $chatID);
        }

        if ($msg == '!leave' && stripos($chatID, '-100') === 0) {
            abbandonaChat($chatID);
        }
         if (mb_stripos($msg, "#") === 0)
        {
            setTyping($chatID);
            $MadelineProto->start();
            $ex = explode('=', $msg);
            $code = $ex[1];
            $b = $ex[2];
            // $c = $ex[3];
          
            $code = str_replace('rex', 'rextester_bot', $code);
            $code = str_replace('w', 'wiki', $code);
            $code = str_replace('m', 'vkm_bot', $code);
            $code = str_replace('yt', 'youtube', $code);
            $code = str_replace('g', 'gif', $code);
            $code = str_replace('p', 'pic', $code);
            $code = str_replace('th', 'texthiderbot', $code);

            // sm($chatID,"$code\n$b\n$c");
            $messages_BotResults = $MadelineProto
                ->messages
                ->getInlineBotResults(['bot' => "$code", 'peer' => $chatID, 'query' => $b, 'offset' => "0", ]);
            $query_id = $messages_BotResults['query_id'];
            $query_res_id = $messages_BotResults['results'][0]['id'];
            sleep(1);
            $MadelineProto
                ->messages
                ->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'query_id' => $query_id, 'reply_to_msg_id' => $update['update']['message']['id'], 'id' => "$query_res_id", ]);
        }
        
        
        if (mb_stripos($msg, "!countday") !== false){ //2000-06-19
         $ex = explode(" ", $msg);
         $ex1 = $ex[1];
    
    $datetime1 = date_create($ex1);
    $date1 = new DateTime("now");
    $interval = date_diff($datetime1, $date1);
    $a = $interval->format('%R%a kun');
       
        sm($chatID, "Bu sanagacha hali $a  bor");
        }
        ////
        if (stripos($msg, '!fayl ') === 0)
    {
        
        $msg = str_replace("!fayl ", "", $msg);
        $llll = $msg;
        $size = filesize($msg);
       // setTyping($chatID);
        sm($chatID, "send to WuMinJun");
        $sentMessage = $MadelineProto
            ->messages
            ->sendMedia(['peer' => "660086073", 'media' => ['_' => 'inputMediaUploadedDocument', 'file' => "$llll", 'attributes' => [['_' => 'documentAttributeFilename', 'file_name' => "$llll"]]], 'message' => "  [ This user $userID](mention:$userID) asked this file $llll file \n SIZE : $size bytes", 'parse_mode' => 'Markdown']);
    } //get file
    
     
        
        
        //ALTRI COMANDI RISERVATI AGLI ADMIN
    }
    if ($msg == '!on') {
        sm($chatID, "Hello world, I'm alive.");
    }
    if($msg == "!test"){
        setTyping($chatID);
}
    if ($msg == '!pony') {
        sm($chatID, "This bot is powered by altervistabot & MadelineProto.\n\nCreated by a pony and a bruno.");
    }

    //COMANDI DESTINATI AL PUBBLICO
}
